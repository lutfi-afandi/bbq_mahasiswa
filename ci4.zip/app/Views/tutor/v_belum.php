<div class="col-md-6 ">
    <div class="card card-default">
        <div class="card-header bg-info">
            <h3 class="card-title">
                <i class="fas fa-exclamation-triangle"></i>
                Informasi
            </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="callout callout-info">
                <h5>Mohon Maaf!</h5>

                <p>Antum belum mendapat kelompok Praktikan</p>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>